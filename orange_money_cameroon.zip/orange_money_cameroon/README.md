# Orange Money Cameroon - Flutter UI Mockup

A Flutter UI mockup for the Orange Money Cameroon mobile app.

## Structure

```
lib/
├── main.dart               # App entry point & navigation
└── pages/
    ├── home_page.dart      # Dashboard with balance & quick actions
    ├── transfer_page.dart  # Money transfer flow
    ├── bill_page.dart      # Bill payment (ENEO, CAMWATER, etc.)
    └── pay_page.dart       # QR code / merchant pay scanner
```

## Getting Started

1. Create a new Flutter project
2. Replace the `lib/` folder with the one from this repo
3. Run `flutter pub get`
4. Run `flutter run`

## Theme

- Primary: `#FF7900` (Orange)
- Secondary: Black
- Font: Helvetica
