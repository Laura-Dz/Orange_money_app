import 'package:flutter/material.dart';

class BillPage extends StatelessWidget {
  const BillPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pay Bills', style: TextStyle(fontWeight: FontWeight.bold))),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search for a biller...', prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                filled: true, fillColor: Colors.grey[200],
              ),
            ),
          ),
          Expanded(
            child: ListView(
              children: [
                _buildSectionHeader('Utilities'),
                _buildBillerItem('ENEO', 'Electricity'),
                _buildBillerItem('CAMWATER', 'Water'),
                _buildSectionHeader('TV & Internet'),
                _buildBillerItem('CANAL+', 'TV Subscription'),
                _buildBillerItem('CAMTEL', 'Internet/Landline'),
                _buildSectionHeader('Education'),
                _buildBillerItem('University Fees', 'Campus payment'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey)),
    );
  }

  Widget _buildBillerItem(String name, String type) {
    return ListTile(
      leading: Container(
        width: 48, height: 48,
        decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(8)),
        child: const Icon(Icons.business, color: Color(0xFFFF7900)),
      ),
      title: Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(type),
      trailing: const Icon(Icons.chevron_right),
      onTap: () {},
    );
  }
}
