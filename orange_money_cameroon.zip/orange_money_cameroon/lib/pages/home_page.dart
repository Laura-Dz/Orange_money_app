import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _showBalance = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text('Orange Money', style: TextStyle(color: Color(0xFFFF7900), fontWeight: FontWeight.bold)),
        actions: [
          IconButton(icon: const Icon(Icons.notifications_none, color: Colors.black), onPressed: () {}),
          const CircleAvatar(backgroundColor: Color(0xFFFF7900), child: Icon(Icons.person, color: Colors.white)),
          const SizedBox(width: 16),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Good morning,', style: TextStyle(fontSize: 16, color: Colors.grey)),
                  const Text('SuperCoder', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 20),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(16)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Orange Money Balance', style: TextStyle(color: Colors.white70)),
                            GestureDetector(
                              onTap: () => setState(() => _showBalance = !_showBalance),
                              child: Icon(_showBalance ? Icons.visibility : Icons.visibility_off, color: Colors.white70, size: 20),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(_showBalance ? '45,250 FCFA' : '•••••• FCFA', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 4,
                mainAxisSpacing: 20,
                crossAxisSpacing: 10,
                children: [
                  _buildQuickAction(context, Icons.swap_horiz, 'Transfer', '/transfer'),
                  _buildQuickAction(context, Icons.receipt_long, 'Bills', '/bill'),
                  _buildQuickAction(context, Icons.phone_android, 'Airtime', null),
                  _buildQuickAction(context, Icons.shopping_bag, 'Merchant', '/pay'),
                  _buildQuickAction(context, Icons.account_balance, 'Bank', null),
                  _buildQuickAction(context, Icons.stars, 'Orange Club', null),
                  _buildQuickAction(context, Icons.security, 'Insurance', null),
                  _buildQuickAction(context, Icons.grid_view, 'More', null),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Padding(padding: EdgeInsets.symmetric(horizontal: 16.0), child: Text('Promotions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
            const SizedBox(height: 12),
            SizedBox(
              height: 150,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  _buildPromoCard('Win 1 Million FCFA!', const Color(0xFFFF7900)),
                  _buildPromoCard('Double your Data', Colors.black),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickAction(BuildContext context, IconData icon, String label, String? route) {
    return GestureDetector(
      onTap: () { if (route != null) Navigator.pushNamed(context, route); },
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: const Color(0xFFF5F5F5), borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: const Color(0xFFFF7900)),
          ),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 12), textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }

  Widget _buildPromoCard(String title, Color color) {
    return Container(
      width: 280, margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(16)),
      child: Center(child: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18))),
    );
  }
}
